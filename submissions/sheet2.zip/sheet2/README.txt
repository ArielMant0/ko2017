﻿P2 - Anweisungen:

Der Solver für Aufgabenteil a) befindet sich in der Datei "FractionalSolver.java".
In Main.java muss der Aufrauf "runSolver(new FractionalSolver(), instance)" ausgeführt werden, um ihn zu verwenden.

Der Solver für Aufgabenteil b) befindet sich in der Datei "BinaryHeuristicSolver.java".
In Main.java muss der Aufrauf "runSolver(new BinaryHeuristicSolver(), instance)" ausgeführt werden, um ihn zu verwenden.
