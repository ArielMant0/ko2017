package tabusearch;

public abstract class Attribute implements Comparable<Attribute> {

    public abstract int compareTo(Attribute other);
}